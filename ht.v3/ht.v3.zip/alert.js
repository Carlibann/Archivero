function aler(){
    window.alert("conexion fallida" );
    
}


function confir() {
    window.confirm("Datos almacenados");
    
}

function promp(){
    window.prompt("cargando");
}

function alertaa(){
    swal("Good job!", "You clicked the button!", "success");

}

