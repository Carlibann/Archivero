<?php
session_start();
session_unset();
if(session_destroy())
{
    header("location:login.php");
}

/*session_start();
if(session_destroy())
{
    header("location:login.php");
}*/




